package com.hotel.services.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotel.services.entity.Hotel;

public interface HotelRepository extends JpaRepository<Hotel,String>{

}
