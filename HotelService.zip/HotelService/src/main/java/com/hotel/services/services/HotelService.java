package com.hotel.services.services;

import com.hotel.services.entity.Hotel;
import java.util.List;

public interface HotelService {
	
    Hotel addHotel(Hotel hotel);
    
    List<Hotel> getAllHotels();
    
    Hotel getHotelById(String id);
    
    Hotel updateHotel(String id, Hotel hotel);
    
    void deleteHotel(String id);
}
