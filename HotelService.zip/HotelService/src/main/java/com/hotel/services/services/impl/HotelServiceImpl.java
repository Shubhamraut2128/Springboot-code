package com.hotel.services.services.impl;


import com.hotel.services.entity.Hotel;
import com.hotel.services.repository.HotelRepository;
import com.hotel.services.services.HotelService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HotelServiceImpl implements HotelService {

    @Autowired
    private HotelRepository hotelRepository;

    @Override
    public Hotel addHotel(Hotel hotel) {
        return hotelRepository.save(hotel);
    }

    @Override
    public List<Hotel> getAllHotels() {
        return hotelRepository.findAll();
    }

    @Override
    public Hotel getHotelById(String id) {
        Optional<Hotel> hotel = hotelRepository.findById(id);
        return hotel.orElseThrow(() -> new RuntimeException("Hotel not found with id: " + id));
    }

    @Override
    public Hotel updateHotel(String id, Hotel hotel) {
        if (!hotelRepository.existsById(id)) {
            throw new RuntimeException("Hotel not found with id: " + id);
        }
        hotel.setId(id); // This should now work as the setter exists
        return hotelRepository.save(hotel);
    }

    @Override
    public void deleteHotel(String id) {
        if (!hotelRepository.existsById(id)) {
            throw new RuntimeException("Hotel not found with id: " + id);
        }
        hotelRepository.deleteById(id);
    }
}
