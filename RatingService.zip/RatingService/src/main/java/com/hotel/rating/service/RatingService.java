package com.hotel.rating.service;

import java.util.List;

import com.hotel.rating.entity.Rating;

public interface RatingService {
	
	
	 //create 
	Rating create(Rating rating);
	
	//getall
	List<Rating> getRatings();
	
	List<Rating> getRatingByUserId(String userId);
	
	List<Rating>getRatingByHotelId(String hotelId);

}
