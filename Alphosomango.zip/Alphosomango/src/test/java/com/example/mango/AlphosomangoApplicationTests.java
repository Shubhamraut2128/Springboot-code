package com.example.mango;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlphosomangoApplicationTests {

	@Test
	void contextLoads() {
	}

}
