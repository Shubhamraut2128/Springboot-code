package com.example.mango;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlphosomangoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlphosomangoApplication.class, args);
	}

}
