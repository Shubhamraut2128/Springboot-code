package com.example.mango.service.impl;

import com.example.mango.entity.Client;
import com.example.mango.repository.ClientRepository;
import com.example.mango.service.ClientService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ClientServiceImpl implements ClientService, org.springframework.security.core.userdetails.UserDetailsService {
    
	
	@Autowired 
	private ClientRepository clientRepository;
	
    private List<Client> clientList = new ArrayList<>(); // In-memory client list (for now)

    @Override
    public Client createClient(Client client) {
        client.setId((long) (clientList.size() + 1)); // Simple ID assignment, typically handled by DB
        clientList.add(client);
        return client;
    }

    @Override
    public Client getClientById(Long id) {
        Optional<Client> client = clientList.stream().filter(c -> c.getId().equals(id)).findFirst();
        return client.orElse(null); 
    }

    @Override
    public List<Client> getAllClients() {
        return clientList;
    }

    @Override
    public boolean deleteClient(Long id) {
        if (clientRepository.existsById(id)) {
            clientRepository.deleteById(id);
            return true;  // Successfully deleted the client
        }
        return false;  // Client not found
    }

    @Override
    public Client updateClient(Long id, Client client) {
        Client existingClient = getClientById(id);
        if (existingClient != null) {
            existingClient.setEmail(client.getEmail());
            existingClient.setPassword(client.getPassword());
            existingClient.setRole(client.getRole());
            return existingClient;
        }
        return null;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Searching for the client by email (acting as username in this case)
        Client client = clientList.stream()
                .filter(c -> c.getEmail().equals(username))
                .findFirst()
                .orElseThrow(() -> new UsernameNotFoundException("Client not found with username: " + username));

        // Returning the user as a Spring Security User object
        return User.builder()
                .username(client.getEmail())  // Using email as username
                .password(client.getPassword())
                .roles(client.getRole()) // Assuming role is stored in the client entity
                .build();
    }
}
