package com.example.mango.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.example.mango.entity.Client;

public interface ClientService extends UserDetailsService  {

	    Client createClient(Client client);

	    Client getClientById(Long id);

	    List<Client> getAllClients();

	    boolean deleteClient(Long id);

	    Client updateClient(Long id, Client client);
	}