package com.example.mango.controller;

import com.example.mango.entity.Client;
import com.example.mango.entity.JwtResponse;
import com.example.mango.jwt.JwtUtil;
import com.example.mango.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clients")
public class ClientController {

    private final ClientService clientService;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    public ClientController(ClientService clientService, JwtUtil jwtUtil, AuthenticationManager authenticationManager) {
        this.clientService = clientService;
        this.jwtUtil = jwtUtil;
        this.authenticationManager = authenticationManager;
    }

    @PostMapping("/register")
    public ResponseEntity<JwtResponse> registerUser(@RequestBody Client client) {
        try {
            client.setPassword(passwordEncoder.encode(client.getPassword()));
            clientService.createClient(client);

            UserDetails userDetails = clientService.loadUserByUsername(client.getEmail());
            String token = jwtUtil.generateToken(userDetails.getUsername());

            return new ResponseEntity<>(new JwtResponse(token, client.getEmail()), HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(new JwtResponse("Error registering user", null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<JwtResponse> loginClient(@RequestBody Client client) {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(client.getEmail(), client.getPassword()));
            String token = jwtUtil.generateToken(client.getEmail());

            return ResponseEntity.ok(new JwtResponse(token, client.getEmail()));
        } catch (Exception e) {
            return new ResponseEntity<>(new JwtResponse("Invalid credentials", null), HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logoutClient() {
        return ResponseEntity.ok("You have been logged out. Please remove the token from client storage.");
    }

    @PostMapping("/postdata")
    public ResponseEntity<Client> createClient(@RequestBody Client client) {
        Client createdClient = clientService.createClient(client);
        return new ResponseEntity<>(createdClient, HttpStatus.CREATED);
    }

    @GetMapping("/getdata/{id}")
    public ResponseEntity<Client> getClientById(@PathVariable Long id) {
        Client client = clientService.getClientById(id);
        if (client != null) {
            return new ResponseEntity<>(client, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/getdata")
    public ResponseEntity<List<Client>> getAllClients() {
        List<Client> clients = clientService.getAllClients();
        return new ResponseEntity<>(clients, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Client> updateClient(@PathVariable Long id, @RequestBody Client client) {
        Client updatedClient = clientService.updateClient(id, client);
        if (updatedClient != null) {
            return new ResponseEntity<>(updatedClient, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteClient(@PathVariable Long id) {
        boolean isDeleted = clientService.deleteClient(id);
        if (isDeleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
