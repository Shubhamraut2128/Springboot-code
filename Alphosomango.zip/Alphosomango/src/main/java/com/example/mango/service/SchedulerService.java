package com.example.mango.service;


import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class SchedulerService {

    @Scheduled(fixedRate = 10000) // every 10 seconds
    public void runEveryTenSeconds() {
        System.out.println("Scheduled task running at: " + LocalDateTime.now());
    }

    @Scheduled(cron = "0 0 9 * * *") // every day at 9 AM
    public void runDailyAtNineAM() {
        System.out.println("Daily task triggered at: " + LocalDateTime.now());
    }
}
