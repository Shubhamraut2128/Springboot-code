package com.empl.operation.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.empl.operation.model.Account;
import com.empl.operation.service.AccountService;



@Controller
@RestController
public class BankController {

	
	@Autowired
    @Lazy
	private AccountService accountService;
	
	@GetMapping("/dashbord")
	public String dashboard(Model model) {
		String username =SecurityContextHolder.getContext().getAuthentication().getName();
		Account account =accountService.findAccountByUsername(username);
		model.addAttribute("account", account);
		return "dashbord";			
	}
	
	@GetMapping("/register")
	public String showRegisterForm() {
		return "register";
	}
	
	@PostMapping("/register")
	public String registerAccout(@RequestParam String username,@RequestParam String password,Model model) {
		 
		try {
			accountService.registerAccount(username, password);
			return "redirect:/login";
		}catch(RuntimeException e) {
			model.addAttribute("error" , e.getMessage());
			return "register";
		}
		
	}
	
	@GetMapping("/login")
	public String login() {
		return "/login";
	}
	
	@PostMapping("/deposit")
	public String deposit(@RequestParam BigDecimal amount) {
		String username =SecurityContextHolder.getContext().getAuthentication().getName();
		Account account =accountService.findAccountByUsername(username);
		accountService.deposit(account, amount);
		return "redirect:/dashboard";
	}
	@PostMapping("/withdraw")
	public String withdraw(@RequestParam BigDecimal amount ,Model model) {
		String username =SecurityContextHolder.getContext().getAuthentication().getName();
		Account account = accountService.findAccountByUsername(username);
		
		try {
			accountService.withdraw(account, amount);
		}catch(RuntimeException e) {
			model.addAttribute("error",e.getMessage());
			model.addAttribute("account",account);
			return"dashboard";
		}
		
		return"redirect:/dashboard";
				
	}
	
	  @GetMapping("/transaction")
	  public String transacationHistory(Model model) {
		  String username =SecurityContextHolder.getContext().getAuthentication().getName();
		  Account account =accountService.findAccountByUsername(username);
		  model.addAttribute("transaction",accountService.getTransactionHistory(account));
		  return "transaction";
	  }
	  @PostMapping("/transfer")
	  
	  public String transferAmount(@RequestParam BigDecimal amount,Model model) {
		   String username =SecurityContextHolder.getContext().getAuthentication().getName();
		   Account formAccount =accountService.findAccountByUsername(username);
		   
		   try {
			   accountService.transferAmount(formAccount, username, amount);
		   }catch(RuntimeException e) {
			   model.addAttribute("error",e.getMessage());
			   model.addAttribute("account",formAccount);
			   return"dashboard";
			   }
		return username;
	  }
}
