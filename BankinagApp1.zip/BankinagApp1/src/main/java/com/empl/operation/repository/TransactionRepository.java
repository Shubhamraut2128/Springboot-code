package com.empl.operation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import jakarta.transaction.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

	List<com.empl.operation.model.Transaction> findByAccountId(Long accountId);

	void save(com.empl.operation.model.Transaction transaction);
}
