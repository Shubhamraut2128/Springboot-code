package com.empl.operation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankinagApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
