package com.example.auth.service;

import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

@Service
public class OtpService {
    private final Map<String, String> otpMap = new ConcurrentHashMap<>();

    public void generateOtp(String mobile) {
        String otp = String.valueOf(new Random().nextInt(899999) + 100000);
        otpMap.put(mobile, otp);
        System.out.println("OTP for " + mobile + ": " + otp);
    }

    public boolean verifyOtp(String mobile, String otp) {
        return otp.equals(otpMap.get(mobile));
    }
}
