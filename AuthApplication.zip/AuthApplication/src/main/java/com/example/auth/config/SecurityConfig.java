package com.example.auth.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf().disable() // Disable CSRF for stateless or web API
            .authorizeRequests()
                .requestMatchers("/auth/**", "/oauth2/**", "/login/**", "/").permitAll() // Allow open routes
                .anyRequest().authenticated() // Secure all other routes
            .and()
            .oauth2Login() // Enable OAuth2 login
                .defaultSuccessUrl("/user", true); // Redirect to /user on successful login
        return http.build();
    }

        @Bean
        public ClientRegistrationRepository clientRegistrationRepository() {
            return new InMemoryClientRegistrationRepository(
                ClientRegistration.withRegistrationId("google")
                    .clientId("YOUR_GOOGLE_CLIENT_ID")
                    .clientSecret("YOUR_GOOGLE_CLIENT_SECRET")
                    .scope("profile", "email")
                    .redirectUri("{baseUrl}/login/oauth2/code/{registrationId}")
                    .authorizationUri("https://accounts.google.com/o/oauth2/auth")
                    .tokenUri("https://oauth2.googleapis.com/token")
                    .userInfoUri("https://www.googleapis.com/oauth2/v3/userinfo")
                    .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
                    .build());
        }
    }

