package com.example.fastag.service;

import com.example.fastag.model.ParkingSession;

import java.util.List;
import java.util.Optional;

public interface ParkingSessionService {
	
    List<ParkingSession> getAllSessions();
    
    Optional<ParkingSession> getSessionById(Long id);
    
    ParkingSession createSession(ParkingSession session);
    
    Optional<ParkingSession> updateSession(Long id, ParkingSession session);
    
    boolean deleteSession(Long id);
}
