package com.example.fastag.service.impl;

import com.example.fastag.model.Lane;
import com.example.fastag.model.Plaza;
import com.example.fastag.repository.LaneRepository;
import com.example.fastag.repository.PlazaRepository;
import com.example.fastag.service.LaneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LaneServiceImpl implements LaneService {

    @Autowired
    private LaneRepository laneRepository;

    @Autowired
    private PlazaRepository plazaRepository;

    @Override
    public List<Lane> getAllLanes() {
        return laneRepository.findAll();
    }

    @Override
    public Optional<Lane> getLaneById(Long id) {
        return laneRepository.findById(id);
    }

    @Override
    public Optional<Lane> createLane(Lane lane) {
        if (lane.getPlaza() == null || lane.getPlaza().getPlazaId() == null) {
            return Optional.empty();
        }
        Optional<Plaza> plazaOpt = plazaRepository.findById(lane.getPlaza().getPlazaId());
        if (plazaOpt.isPresent()) {
            lane.setPlaza(plazaOpt.get());
            Lane saved = laneRepository.save(lane);
            return Optional.of(saved);
        } else {
            return Optional.empty();
        }
    }

    @Override
    public Optional<Lane> updateLane(Long id, Lane req) {
        return laneRepository.findById(id).map(existing -> {
            existing.setLaneIdentifier(req.getLaneIdentifier());
            existing.setDirection(req.getDirection());
            existing.setReaderId(req.getReaderId());
            existing.setLaneStatus(req.getLaneStatus());
            existing.setLaneMode(req.getLaneMode());
            existing.setLaneType(req.getLaneType());
            return laneRepository.save(existing);
        });
    }

    @Override
    public boolean deleteLane(Long id) {
        return laneRepository.findById(id).map(lane -> {
            laneRepository.delete(lane);
            return true;
        }).orElse(false);
    }
}
