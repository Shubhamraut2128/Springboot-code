package com.example.fastag.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fastag.model.NetcTransaction;

public interface NetcTransactionRepository extends JpaRepository<NetcTransaction, Long> {

}
