package com.example.fastag.service;


import com.example.fastag.model.Plaza;

import java.util.List;
import java.util.Optional;

public interface PlazaService {
	
	Plaza createPlaza(Plaza plaza);
	
    Plaza updatePlaza(Long id, Plaza plaza);
    
    boolean deletePlaza(Long id);
    
    Optional<Plaza> getPlazaById(Long id);
    
    List<Plaza> getAllPlazas();
}

