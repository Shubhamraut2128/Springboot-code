package com.example.fastag.service.impl;

import com.example.fastag.service.PlazaService;


import com.example.fastag.model.Plaza;
import com.example.fastag.repository.PlazaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PlazaServiceImpl implements PlazaService {

    @Autowired
    private PlazaRepository plazaRepository;

    @Override
    public Plaza createPlaza(Plaza plaza) {
        return plazaRepository.save(plaza);
    }

    @Override
    public Plaza updatePlaza(Long id, Plaza updatedPlaza) {
        return plazaRepository.findById(id).map(plaza -> {
            plaza.setPlazaName(updatedPlaza.getPlazaName());
            plaza.setPlazaType(updatedPlaza.getPlazaType());
            plaza.setGeoCode(updatedPlaza.getGeoCode());
            plaza.setAddress(updatedPlaza.getAddress());
            plaza.setFromDistrict(updatedPlaza.getFromDistrict());
            plaza.setToDistrict(updatedPlaza.getToDistrict());
            plaza.setAgencyCode(updatedPlaza.getAgencyCode());
            return plazaRepository.save(plaza);
        }).orElseThrow(() -> new RuntimeException("Plaza not found with id: " + id));
    }

    @Override
    public boolean deletePlaza(Long id) {
        return plazaRepository.findById(id).map(p -> {
            plazaRepository.delete(p);
            return true;
        }).orElse(false);
    }
    
    @Override
    public Optional<Plaza> getPlazaById(Long id) {
        return plazaRepository.findById(id);
    }

    @Override
    public List<Plaza> getAllPlazas() {
        return plazaRepository.findAll();
    }
}
