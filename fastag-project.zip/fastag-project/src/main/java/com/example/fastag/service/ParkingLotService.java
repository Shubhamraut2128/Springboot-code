package com.example.fastag.service;


import com.example.fastag.model.ParkingLot;

import java.util.List;
import java.util.Optional;

public interface ParkingLotService {
	
    List<ParkingLot> getAllParkingLots();
    
    Optional<ParkingLot> getParkingLotById(Long id);
    
    ParkingLot createParkingLot(ParkingLot parkingLot);
    
    Optional<ParkingLot> updateParkingLot(Long id, ParkingLot parkingLot);
    
    boolean deleteParkingLot(Long id);
}
