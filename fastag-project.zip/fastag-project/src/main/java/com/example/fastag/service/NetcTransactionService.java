package com.example.fastag.service;

import java.util.List;
import java.util.Optional;

import com.example.fastag.model.NetcTransaction;

public interface NetcTransactionService {
     
	
	List<NetcTransaction> getAllTransactions();
	
    Optional<NetcTransaction> getTransactionById(Long id);
    
    NetcTransaction createTransaction(NetcTransaction transaction);
    
    Optional<NetcTransaction> updateTransaction(Long id, NetcTransaction transaction);
    
    boolean deleteTransaction(Long id);
}
