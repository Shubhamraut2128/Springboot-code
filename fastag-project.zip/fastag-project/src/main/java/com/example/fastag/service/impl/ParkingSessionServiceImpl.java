package com.example.fastag.service.impl;


import com.example.fastag.model.ParkingSession;
import com.example.fastag.repository.ParkingLotRepository;
import com.example.fastag.repository.ParkingSessionRepository;
import com.example.fastag.repository.VehicleRepository;
import com.example.fastag.service.ParkingSessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ParkingSessionServiceImpl implements ParkingSessionService {

    @Autowired
    private ParkingSessionRepository parkingSessionRepository;

    @Autowired
    private ParkingLotRepository parkingLotRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    @Override
    public List<ParkingSession> getAllSessions() {
        return parkingSessionRepository.findAll();
    }

    @Override
    public Optional<ParkingSession> getSessionById(Long id) {
        return parkingSessionRepository.findById(id);
    }

    @Override
    public ParkingSession createSession(ParkingSession session) {
        if (session.getParkingLot() == null || session.getParkingLot().getParkingLotId() == null) {
            throw new IllegalArgumentException("Parking lot ID is required.");
        }
        if (session.getVehicle() == null || session.getVehicle().getVehicleId() == null) {
            throw new IllegalArgumentException("Vehicle ID is required.");
        }

        session.setParkingLot(parkingLotRepository.findById(session.getParkingLot().getParkingLotId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid Parking Lot ID")));

        session.setVehicle(vehicleRepository.findById(session.getVehicle().getVehicleId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid Vehicle ID")));

        return parkingSessionRepository.save(session);
    }

    @Override
    public Optional<ParkingSession> updateSession(Long id, ParkingSession request) {
        return parkingSessionRepository.findById(id).map(existing -> {
            existing.setEntryTime(request.getEntryTime());
            existing.setExitTime(request.getExitTime());
            existing.setStatus(request.getStatus());
            existing.setTotalFee(request.getTotalFee());
            existing.setPaidViaTag(request.isPaidViaTag());
            return parkingSessionRepository.save(existing);
        });
    }

    @Override
    public boolean deleteSession(Long id) {
        return parkingSessionRepository.findById(id).map(existing -> {
            parkingSessionRepository.delete(existing);
            return true;
        }).orElse(false);
    }
}
