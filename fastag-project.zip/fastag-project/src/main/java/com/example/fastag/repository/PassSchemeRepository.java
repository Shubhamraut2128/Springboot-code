package com.example.fastag.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fastag.model.PassScheme;

public interface PassSchemeRepository extends JpaRepository<PassScheme, Long> {

}
