package com.example.fastag.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fastag.model.Plaza;

public interface PlazaRepository extends JpaRepository<Plaza, Long>  {

}
