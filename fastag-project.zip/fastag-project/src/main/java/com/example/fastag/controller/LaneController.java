package com.example.fastag.controller;

import com.example.fastag.model.Lane;
import com.example.fastag.repository.LaneRepository;
import com.example.fastag.repository.PlazaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/lanes")
public class LaneController {

    @Autowired
    private LaneRepository laneRepository;

    @Autowired
    private PlazaRepository plazaRepository;

    @GetMapping
    public List<Lane> getAllLanes() {
        return laneRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Lane> getLaneById(@PathVariable Long id) {
        return laneRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Lane> createLane(@RequestBody Lane lane) {
        if (lane.getPlaza() == null || lane.getPlaza().getPlazaId() == null) {
            return ResponseEntity.badRequest().build();
        }
        return plazaRepository.findById(lane.getPlaza().getPlazaId()).map(plaza -> {
            lane.setPlaza(plaza);
            Lane saved = laneRepository.save(lane);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.badRequest().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Lane> updateLane(@PathVariable Long id, @RequestBody Lane req) {
        return laneRepository.findById(id).map(existing -> {
            existing.setLaneIdentifier(req.getLaneIdentifier());
            existing.setDirection(req.getDirection());
            existing.setReaderId(req.getReaderId());
            existing.setLaneStatus(req.getLaneStatus());
            existing.setLaneMode(req.getLaneMode());
            existing.setLaneType(req.getLaneType());
            return ResponseEntity.ok(laneRepository.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteLane(@PathVariable Long id) {
        return laneRepository.findById(id).map(l -> {
            laneRepository.delete(l);
            return ResponseEntity.noContent().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
