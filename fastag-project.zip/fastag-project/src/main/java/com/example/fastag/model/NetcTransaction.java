package com.example.fastag.model;


import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "netc_transaction", schema = "fastag")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NetcTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long netcTxnId;

    @Column(nullable = false, length = 36)
    private String externalTxnId;

    @ManyToOne
    @JoinColumn(name = "plaza_id", nullable = false)
    private Plaza plaza;

    @ManyToOne
    @JoinColumn(name = "lane_id")
    private Lane lane;

    @ManyToOne
    @JoinColumn(name = "vehicle_id")
    private Vehicle vehicle;
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private AppUser user;

    @Column(length = 10)
    private String txnType;     // DEBIT, CREDIT, NON_FIN

    @Column(length = 15)
    private String txnStatus;   // ACCEPTED, DECLINED, INPROCESS

    @Column(length = 10)
    private String txnMode;     // Tag, Cash, Other

    private LocalDateTime txnTimestamp;
    private LocalDateTime readerReadTime;

    @Column(length = 50)
    private String retrievalRefNumber;

    @Column(length = 20)
    private String issuerId;

    @Column(length = 20)
    private String acquirerInstitutionId;

    private BigDecimal tollFare;
    
    @Column(length = 20)
    private String fareType;    // FULL, RETURN, DISCOUNTED

    @Column(length = 20)
    private String approvalNumber;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    public void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (updatedAt == null) {
            updatedAt = LocalDateTime.now();
        }
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

	public Long getNetcTxnId() {
		return netcTxnId;
	}

	public void setNetcTxnId(Long netcTxnId) {
		this.netcTxnId = netcTxnId;
	}

	public String getExternalTxnId() {
		return externalTxnId;
	}

	public void setExternalTxnId(String externalTxnId) {
		this.externalTxnId = externalTxnId;
	}

	public Plaza getPlaza() {
		return plaza;
	}

	public void setPlaza(Plaza plaza) {
		this.plaza = plaza;
	}

	public Lane getLane() {
		return lane;
	}

	public void setLane(Lane lane) {
		this.lane = lane;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	public String getTxnMode() {
		return txnMode;
	}

	public void setTxnMode(String txnMode) {
		this.txnMode = txnMode;
	}

	public LocalDateTime getTxnTimestamp() {
		return txnTimestamp;
	}

	public void setTxnTimestamp(LocalDateTime txnTimestamp) {
		this.txnTimestamp = txnTimestamp;
	}

	public LocalDateTime getReaderReadTime() {
		return readerReadTime;
	}

	public void setReaderReadTime(LocalDateTime readerReadTime) {
		this.readerReadTime = readerReadTime;
	}

	public String getRetrievalRefNumber() {
		return retrievalRefNumber;
	}

	public void setRetrievalRefNumber(String retrievalRefNumber) {
		this.retrievalRefNumber = retrievalRefNumber;
	}

	public String getIssuerId() {
		return issuerId;
	}

	public void setIssuerId(String issuerId) {
		this.issuerId = issuerId;
	}

	public String getAcquirerInstitutionId() {
		return acquirerInstitutionId;
	}

	public void setAcquirerInstitutionId(String acquirerInstitutionId) {
		this.acquirerInstitutionId = acquirerInstitutionId;
	}

	public BigDecimal getTollFare() {
		return tollFare;
	}

	public void setTollFare(BigDecimal tollFare) {
		this.tollFare = tollFare;
	}

	public String getFareType() {
		return fareType;
	}

	public void setFareType(String fareType) {
		this.fareType = fareType;
	}

	public String getApprovalNumber() {
		return approvalNumber;
	}

	public void setApprovalNumber(String approvalNumber) {
		this.approvalNumber = approvalNumber;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
    
}
