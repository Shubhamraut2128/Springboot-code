package com.example.fastag.service;

import com.example.fastag.model.ExceptionList;

import java.util.List;
import java.util.Optional;

public interface ExceptionListService {
	
    List<ExceptionList> getAllExceptions();
    
    Optional<ExceptionList> getExceptionById(Long id);
    
    ExceptionList createException(ExceptionList exceptionList);
    
    Optional<ExceptionList> updateException(Long id, ExceptionList exceptionList);
    
    boolean deleteException(Long id);
}
