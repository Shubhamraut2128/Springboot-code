package com.example.fastag.controller;

import com.example.fastag.model.Plaza;
import com.example.fastag.repository.PlazaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/plazas")
public class PlazaController {

    @Autowired
    private PlazaRepository plazaRepository;

    @GetMapping
    public List<Plaza> getAllPlazas() {
        return plazaRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Plaza> getPlazaById(@PathVariable Long id) {
        return plazaRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Plaza createPlaza(@RequestBody Plaza plaza) {
        return plazaRepository.save(plaza);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Plaza> updatePlaza(@PathVariable Long id, @RequestBody Plaza request) {
        return plazaRepository.findById(id).map(existing -> {
            existing.setPlazaName(request.getPlazaName());
            existing.setPlazaType(request.getPlazaType());
            existing.setGeoCode(request.getGeoCode());
            existing.setAddress(request.getAddress());
            existing.setFromDistrict(request.getFromDistrict());
            existing.setToDistrict(request.getToDistrict());
            existing.setAgencyCode(request.getAgencyCode());
            // etc.
            return ResponseEntity.ok(plazaRepository.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deletePlaza(@PathVariable Long id) {
        return plazaRepository.findById(id).map(p -> {
            plazaRepository.delete(p);
            return ResponseEntity.<Void>noContent().build(); // explicitly specifying <Void>
        }).orElse(ResponseEntity.notFound().build());
    }
}
