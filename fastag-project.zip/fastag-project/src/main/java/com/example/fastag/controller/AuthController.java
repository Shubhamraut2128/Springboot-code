package com.example.fastag.controller;

import com.example.fastag.model.AppUser;
import com.example.fastag.repository.AppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AppUserRepository userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder; // ✅ Use PasswordEncoder instead of BCryptPasswordEncoder

    @PostMapping("/register")
    public ResponseEntity<AppUser> register(@RequestBody AppUser request) {
        Optional<AppUser> found = userRepo.findByUsername(request.getUsername());
        if (found.isPresent()) {
            return ResponseEntity.badRequest().build();
        }
        // Encode password
        request.setPasswordHash(passwordEncoder.encode(request.getPasswordHash()));
        if(request.getRole() == null) {
            request.setRole("USER");
        }
        AppUser saved = userRepo.save(request);
        return ResponseEntity.ok(saved);
    }
}
