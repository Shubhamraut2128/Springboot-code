package com.example.fastag.service.impl;

import com.example.fastag.model.PassScheme;
import com.example.fastag.repository.PassSchemeRepository;
import com.example.fastag.service.PassSchemeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PassSchemeServiceImpl implements PassSchemeService {

    @Autowired
    private PassSchemeRepository passSchemeRepository;

    @Override
    public List<PassScheme> getAllSchemes() {
        return passSchemeRepository.findAll();
    }

    @Override
    public Optional<PassScheme> getSchemeById(Long id) {
        return passSchemeRepository.findById(id);
    }

    @Override
    public PassScheme createScheme(PassScheme scheme) {
        return passSchemeRepository.save(scheme);
    }

    @Override
    public Optional<PassScheme> updateScheme(Long id, PassScheme request) {
        return passSchemeRepository.findById(id).map(existing -> {
            existing.setSchemeName(request.getSchemeName());
            existing.setVehicleClassId(request.getVehicleClassId());
            existing.setPassType(request.getPassType());
            existing.setAllowedTrips(request.getAllowedTrips());
            existing.setAmount(request.getAmount());
            existing.setCurrency(request.getCurrency());
            existing.setDescription(request.getDescription());
            return passSchemeRepository.save(existing);
        });
    }

    @Override
    public boolean deleteScheme(Long id) {
        return passSchemeRepository.findById(id).map(existing -> {
            passSchemeRepository.delete(existing);
            return true;
        }).orElse(false);
    }
}

