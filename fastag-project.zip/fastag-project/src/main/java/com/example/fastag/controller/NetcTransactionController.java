package com.example.fastag.controller;

import com.example.fastag.model.NetcTransaction;
import com.example.fastag.model.Vehicle;
import com.example.fastag.model.Lane;
import com.example.fastag.model.Plaza;
import com.example.fastag.repository.NetcTransactionRepository;
import com.example.fastag.repository.VehicleRepository;
import com.example.fastag.repository.LaneRepository;
import com.example.fastag.repository.PlazaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/netc-transactions")
public class NetcTransactionController {

    @Autowired
    private NetcTransactionRepository netcTxRepo;

    @Autowired
    private VehicleRepository vehicleRepo;

    @Autowired
    private LaneRepository laneRepo;

    @Autowired
    private PlazaRepository plazaRepo;

    @GetMapping
    public List<NetcTransaction> getAllTransactions() {
        return netcTxRepo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<NetcTransaction> getById(@PathVariable Long id) {
        return netcTxRepo.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<NetcTransaction> createTransaction(@RequestBody NetcTransaction tx) {
        if(tx.getPlaza() == null || tx.getPlaza().getPlazaId() == null) {
            return ResponseEntity.badRequest().build();
        }
        if(tx.getLane() != null && tx.getLane().getLaneId() != null) {
            laneRepo.findById(tx.getLane().getLaneId())
                    .ifPresent(tx::setLane);
        }
        plazaRepo.findById(tx.getPlaza().getPlazaId())
                 .ifPresent(tx::setPlaza);

        if(tx.getVehicle() != null && tx.getVehicle().getVehicleId() != null) {
            vehicleRepo.findById(tx.getVehicle().getVehicleId())
                       .ifPresent(tx::setVehicle);
        }
        NetcTransaction saved = netcTxRepo.save(tx);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<NetcTransaction> updateTx(@PathVariable Long id, @RequestBody NetcTransaction req) {
        return netcTxRepo.findById(id).map(existing -> {
            existing.setExternalTxnId(req.getExternalTxnId());
            existing.setTxnType(req.getTxnType());
            existing.setTxnStatus(req.getTxnStatus());
            existing.setTxnMode(req.getTxnMode());
            existing.setTxnTimestamp(req.getTxnTimestamp());
            existing.setReaderReadTime(req.getReaderReadTime());
            existing.setRetrievalRefNumber(req.getRetrievalRefNumber());
            existing.setIssuerId(req.getIssuerId());
            existing.setAcquirerInstitutionId(req.getAcquirerInstitutionId());
            existing.setTollFare(req.getTollFare());
            existing.setFareType(req.getFareType());
            existing.setApprovalNumber(req.getApprovalNumber());
            // If plaza or lane or vehicle changed, fetch them similarly
            return ResponseEntity.ok(netcTxRepo.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteTx(@PathVariable Long id) {
        return netcTxRepo.findById(id).map(t -> {
            netcTxRepo.delete(t);
            return ResponseEntity.noContent().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
