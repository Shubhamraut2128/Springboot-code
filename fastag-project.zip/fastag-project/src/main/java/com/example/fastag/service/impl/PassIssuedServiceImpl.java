package com.example.fastag.service.impl;

import com.example.fastag.model.PassIssued;
import com.example.fastag.repository.PassIssuedRepository;
import com.example.fastag.service.PassIssuedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PassIssuedServiceImpl implements PassIssuedService {

    @Autowired
    private PassIssuedRepository passIssuedRepository;

    @Override
    public List<PassIssued> getAllPasses() {
        return passIssuedRepository.findAll();
    }

    @Override
    public Optional<PassIssued> getPassById(Long id) {
        return passIssuedRepository.findById(id);
    }

    @Override
    public PassIssued createPass(PassIssued passIssued) {
        return passIssuedRepository.save(passIssued);
    }

    @Override
    public Optional<PassIssued> updatePass(Long id, PassIssued request) {
        return passIssuedRepository.findById(id).map(existing -> {
            existing.setPassScheme(request.getPassScheme());
            existing.setVehicle(request.getVehicle());
            existing.setIssueDate(request.getIssueDate());
            existing.setExpiryDate(request.getExpiryDate());
            existing.setUsedTrips(request.getUsedTrips());
            return passIssuedRepository.save(existing);
        });
    }

    @Override
    public boolean deletePass(Long id) {
        return passIssuedRepository.findById(id).map(existing -> {
            passIssuedRepository.delete(existing);
            return true;
        }).orElse(false);
    }
}
