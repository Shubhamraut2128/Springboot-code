package com.example.fastag.controller;

import com.example.fastag.model.ExceptionList;
import com.example.fastag.repository.ExceptionListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/exceptions")
public class ExceptionListController {

    @Autowired
    private ExceptionListRepository exceptionListRepository;

    @GetMapping
    public List<ExceptionList> getAllExceptions() {
        return exceptionListRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ExceptionList> getExceptionById(@PathVariable Long id) {
        return exceptionListRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ExceptionList createException(@RequestBody ExceptionList exc) {
        return exceptionListRepository.save(exc);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ExceptionList> updateException(@PathVariable Long id, @RequestBody ExceptionList request) {
        return exceptionListRepository.findById(id).map(existing -> {
            existing.setExcCode(request.getExcCode());
            existing.setExcDescription(request.getExcDescription());
            existing.setTagId(request.getTagId());
            existing.setPriority(request.getPriority());
            existing.setLastUpdatedTime(request.getLastUpdatedTime());
            return ResponseEntity.ok(exceptionListRepository.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteException(@PathVariable Long id) {
        return exceptionListRepository.findById(id).map(e -> {
            exceptionListRepository.delete(e);
            return ResponseEntity.noContent().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
