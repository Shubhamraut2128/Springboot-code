package com.example.fastag.model;


import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "lane", schema = "fastag")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Lane {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long laneId;

    @ManyToOne
    @JoinColumn(name = "plaza_id", nullable = false)
    private Plaza plaza;

    @Column(length = 20)
    private String laneIdentifier;

    @Column(length = 2)
    private String direction;  // e.g. N, S, E, W

    @Column(length = 50)
    private String readerId;

    @Column(length = 10)
    private String laneStatus; // OPEN/CLOSE

    @Column(length = 20)
    private String laneMode;   // Normal/Maintenance

    @Column(length = 20)
    private String laneType;   // Dedicated/Hybrid/Handheld/Parking

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    public void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

	public Long getLaneId() {
		return laneId;
	}

	public void setLaneId(Long laneId) {
		this.laneId = laneId;
	}

	public Plaza getPlaza() {
		return plaza;
	}

	public void setPlaza(Plaza plaza) {
		this.plaza = plaza;
	}

	public String getLaneIdentifier() {
		return laneIdentifier;
	}

	public void setLaneIdentifier(String laneIdentifier) {
		this.laneIdentifier = laneIdentifier;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getReaderId() {
		return readerId;
	}

	public void setReaderId(String readerId) {
		this.readerId = readerId;
	}

	public String getLaneStatus() {
		return laneStatus;
	}

	public void setLaneStatus(String laneStatus) {
		this.laneStatus = laneStatus;
	}

	public String getLaneMode() {
		return laneMode;
	}

	public void setLaneMode(String laneMode) {
		this.laneMode = laneMode;
	}

	public String getLaneType() {
		return laneType;
	}

	public void setLaneType(String laneType) {
		this.laneType = laneType;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
    
    
}
