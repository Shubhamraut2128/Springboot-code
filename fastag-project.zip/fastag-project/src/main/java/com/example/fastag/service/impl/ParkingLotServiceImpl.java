package com.example.fastag.service.impl;


import com.example.fastag.model.ParkingLot;
import com.example.fastag.repository.ParkingLotRepository;
import com.example.fastag.repository.PlazaRepository;
import com.example.fastag.service.ParkingLotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ParkingLotServiceImpl implements ParkingLotService {

    @Autowired
    private ParkingLotRepository parkingLotRepository;

    @Autowired
    private PlazaRepository plazaRepository;

    @Override
    public List<ParkingLot> getAllParkingLots() {
        return parkingLotRepository.findAll();
    }

    @Override
    public Optional<ParkingLot> getParkingLotById(Long id) {
        return parkingLotRepository.findById(id);
    }

    @Override
    public ParkingLot createParkingLot(ParkingLot parkingLot) {
        if (parkingLot.getPlaza() != null && parkingLot.getPlaza().getPlazaId() != null) {
            return plazaRepository.findById(parkingLot.getPlaza().getPlazaId())
                    .map(plaza -> {
                        parkingLot.setPlaza(plaza);
                        return parkingLotRepository.save(parkingLot);
                    }).orElseThrow(() -> new IllegalArgumentException("Invalid Plaza ID"));
        }
        throw new IllegalArgumentException("Plaza ID is required");
    }

    @Override
    public Optional<ParkingLot> updateParkingLot(Long id, ParkingLot request) {
        return parkingLotRepository.findById(id).map(existing -> {
            existing.setLotName(request.getLotName());
            existing.setFloorNumber(request.getFloorNumber());
            existing.setCapacity(request.getCapacity());
            existing.setActive(request.isActive());
            return parkingLotRepository.save(existing);
        });
    }

    @Override
    public boolean deleteParkingLot(Long id) {
        return parkingLotRepository.findById(id).map(existing -> {
            parkingLotRepository.delete(existing);
            return true;
        }).orElse(false);
    }
}
