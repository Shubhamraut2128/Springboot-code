package com.example.fastag.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Entity
@Table(name = "app_user", schema = "fastag")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppUser  implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @Column(nullable = false, unique = true, length = 50)
    private String username;

    @Column(nullable = false, length = 120)
    private String passwordHash;  // store hashed passwords, e.g. BCrypt

    @Column(length = 50)
    private String role; // e.g. 'USER', 'ADMIN'

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // If you want to track which netcTransactions this user performed
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = false)
    private List<NetcTransaction> transactions;

    // If you also track user in ParkingSession
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = false)
    private List<ParkingSession> sessions;
    

    @PrePersist
    public void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<NetcTransaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<NetcTransaction> transactions) {
		this.transactions = transactions;
	}

	public List<ParkingSession> getSessions() {
		return sessions;
	}

	public void setSessions(List<ParkingSession> sessions) {
		this.sessions = sessions;
	}

	@Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role));
    }

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return passwordHash;
	}

	public AppUser(Long userId, String username, String passwordHash, String role, LocalDateTime createdAt,
			LocalDateTime updatedAt, List<NetcTransaction> transactions, List<ParkingSession> sessions) {
		super();
		this.userId = userId;
		this.username = username;
		this.passwordHash = passwordHash;
		this.role = role;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.transactions = transactions;
		this.sessions = sessions;
	}

	public AppUser() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "AppUser [userId=" + userId + ", username=" + username + ", passwordHash=" + passwordHash + ", role="
				+ role + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + ", transactions=" + transactions
				+ ", sessions=" + sessions + "]";
	}
	
	
    
}

