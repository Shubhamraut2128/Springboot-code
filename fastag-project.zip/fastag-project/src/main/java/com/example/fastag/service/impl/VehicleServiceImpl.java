package com.example.fastag.service.impl;

import com.example.fastag.model.Vehicle;
import com.example.fastag.repository.VehicleRepository;
import com.example.fastag.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VehicleServiceImpl implements VehicleService {

    @Autowired
    private VehicleRepository vehicleRepository;

    @Override
    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    @Override
    public Optional<Vehicle> getVehicleById(Long id) {
        return vehicleRepository.findById(id);
    }

    @Override
    public Optional<Vehicle> getVehicleByTagId(String tagId) {
        return vehicleRepository.findByTagId(tagId);
    }

    @Override
    public Optional<Vehicle> getVehicleByRegNumber(String regNumber) {
        return vehicleRepository.findByRegNumber(regNumber);
    }

    @Override
    public Vehicle createVehicle(Vehicle vehicle) {
        return vehicleRepository.save(vehicle);
    }

    @Override
    public Optional<Vehicle> updateVehicle(Long id, Vehicle request) {
        return vehicleRepository.findById(id).map(existing -> {
            existing.setTagId(request.getTagId());
            existing.setTid(request.getTid());
            existing.setRegNumber(request.getRegNumber());
            existing.setVehicleClass(request.getVehicleClass());
            existing.setCommercial(request.isCommercial());
            return vehicleRepository.save(existing);
        });
    }

    @Override
    public boolean deleteVehicle(Long id) {
        return vehicleRepository.findById(id).map(vehicle -> {
            vehicleRepository.delete(vehicle);
            return true;
        }).orElse(false);
    }
}
