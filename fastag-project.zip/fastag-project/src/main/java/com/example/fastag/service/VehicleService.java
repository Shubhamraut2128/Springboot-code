package com.example.fastag.service;

import com.example.fastag.model.Vehicle;

import java.util.List;
import java.util.Optional;

public interface VehicleService {
	
    List<Vehicle> getAllVehicles();
    
    Optional<Vehicle> getVehicleById(Long id);
    
    Optional<Vehicle> getVehicleByTagId(String tagId);
    
    Optional<Vehicle> getVehicleByRegNumber(String regNumber);
    
    Vehicle createVehicle(Vehicle vehicle);
    
    Optional<Vehicle> updateVehicle(Long id, Vehicle vehicle);
    
    boolean deleteVehicle(Long id);
}
