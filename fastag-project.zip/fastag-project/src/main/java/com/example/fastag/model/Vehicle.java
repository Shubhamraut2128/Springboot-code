package com.example.fastag.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "vehicle", schema = "fastag")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long vehicleId;

    @Column(unique = true, length = 32)
    private String tagId;

    @Column(length = 32)
    private String tid;

    @Column(length = 20)
    private String regNumber;      // e.g. MH04BY1234

    @Column(length = 10)
    private String vehicleClass;   // e.g. VC4, LCV

    private boolean isCommercial;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Optional: a vehicle can have multiple netcTransactions
    @OneToMany(mappedBy = "vehicle", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<NetcTransaction> transactions;

    // Optional: a vehicle can have multiple parking sessions
    @OneToMany(mappedBy = "vehicle", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ParkingSession> parkingSessions;

    // Optional: a vehicle can have multiple PassIssued
    @OneToMany(mappedBy = "vehicle", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PassIssued> passIssuedList;

    @PrePersist
    public void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getRegNumber() {
		return regNumber;
	}

	public void setRegNumber(String regNumber) {
		this.regNumber = regNumber;
	}

	public String getVehicleClass() {
		return vehicleClass;
	}

	public void setVehicleClass(String vehicleClass) {
		this.vehicleClass = vehicleClass;
	}

	public boolean isCommercial() {
		return isCommercial;
	}

	public void setCommercial(boolean isCommercial) {
		this.isCommercial = isCommercial;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<NetcTransaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<NetcTransaction> transactions) {
		this.transactions = transactions;
	}

	public List<ParkingSession> getParkingSessions() {
		return parkingSessions;
	}

	public void setParkingSessions(List<ParkingSession> parkingSessions) {
		this.parkingSessions = parkingSessions;
	}

	public List<PassIssued> getPassIssuedList() {
		return passIssuedList;
	}

	public void setPassIssuedList(List<PassIssued> passIssuedList) {
		this.passIssuedList = passIssuedList;
	}
    
}
