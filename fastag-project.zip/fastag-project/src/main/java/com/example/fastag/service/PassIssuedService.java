package com.example.fastag.service;

import com.example.fastag.model.PassIssued;

import java.util.List;
import java.util.Optional;

public interface PassIssuedService {
	
    List<PassIssued> getAllPasses();
    
    Optional<PassIssued> getPassById(Long id);
    
    PassIssued createPass(PassIssued passIssued);
    
    Optional<PassIssued> updatePass(Long id, PassIssued passIssued);
    
    boolean deletePass(Long id);
}
