package com.example.fastag.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fastag.model.Lane;

public interface LaneRepository extends JpaRepository<Lane,Long> {
 
	List<Lane> findByPlaza_PlazaId(Long plazaId);
}
