package com.example.fastag.service.impl;

import com.example.fastag.model.NetcTransaction;
import com.example.fastag.repository.NetcTransactionRepository;
import com.example.fastag.service.NetcTransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NetcTransactionServiceImpl implements NetcTransactionService {

    @Autowired
    private NetcTransactionRepository netcTransactionRepository;

    @Override
    public List<NetcTransaction> getAllTransactions() {
        return netcTransactionRepository.findAll();
    }

    @Override
    public Optional<NetcTransaction> getTransactionById(Long id) {
        return netcTransactionRepository.findById(id);
    }

    @Override
    public NetcTransaction createTransaction(NetcTransaction transaction) {
        return netcTransactionRepository.save(transaction);
    }

    @Override
    public Optional<NetcTransaction> updateTransaction(Long id, NetcTransaction request) {
        return netcTransactionRepository.findById(id).map(existing -> {
            existing.setExternalTxnId(request.getExternalTxnId());
            existing.setPlaza(request.getPlaza());
            existing.setLane(request.getLane());
            existing.setVehicle(request.getVehicle());
            existing.setTxnType(request.getTxnType());
            existing.setTxnStatus(request.getTxnStatus());
            existing.setTxnMode(request.getTxnMode());
            existing.setTxnTimestamp(request.getTxnTimestamp());
            existing.setReaderReadTime(request.getReaderReadTime());
            existing.setRetrievalRefNumber(request.getRetrievalRefNumber());
            existing.setIssuerId(request.getIssuerId());
            existing.setAcquirerInstitutionId(request.getAcquirerInstitutionId());
            existing.setTollFare(request.getTollFare());
            existing.setFareType(request.getFareType());
            existing.setApprovalNumber(request.getApprovalNumber());
            return netcTransactionRepository.save(existing);
        });
    }

    @Override
    public boolean deleteTransaction(Long id) {
        return netcTransactionRepository.findById(id).map(txn -> {
            netcTransactionRepository.delete(txn);
            return true;
        }).orElse(false);
    }
}
