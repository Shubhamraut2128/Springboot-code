package com.example.fastag.model;


import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "pass_scheme", schema = "fastag")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PassScheme {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long passSchemeId;

    @Column(nullable = false, length = 50)
    private String schemeName;

    @Column(length = 10)
    private String vehicleClassId;   // e.g. VC4

    @Column(length = 30)
    private String passType;         // e.g. 'Monthly','Local','CalendarMonthly'

    private Integer allowedTrips;

    private BigDecimal amount;

    @Column(length = 3)
    private String currency;         // INR

    @Lob
    private String description;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // A pass scheme can be assigned to multiple vehicles
    @OneToMany(mappedBy = "passScheme", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PassIssued> passIssuedList = new ArrayList<>();

    @PrePersist
    public void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

	public Long getPassSchemeId() {
		return passSchemeId;
	}

	public void setPassSchemeId(Long passSchemeId) {
		this.passSchemeId = passSchemeId;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getVehicleClassId() {
		return vehicleClassId;
	}

	public void setVehicleClassId(String vehicleClassId) {
		this.vehicleClassId = vehicleClassId;
	}

	public String getPassType() {
		return passType;
	}

	public void setPassType(String passType) {
		this.passType = passType;
	}

	public Integer getAllowedTrips() {
		return allowedTrips;
	}

	public void setAllowedTrips(Integer allowedTrips) {
		this.allowedTrips = allowedTrips;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<PassIssued> getPassIssuedList() {
		return passIssuedList;
	}

	public void setPassIssuedList(List<PassIssued> passIssuedList) {
		this.passIssuedList = passIssuedList;
	}
    
}
