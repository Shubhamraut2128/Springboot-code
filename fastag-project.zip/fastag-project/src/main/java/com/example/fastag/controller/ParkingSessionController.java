package com.example.fastag.controller;

import com.example.fastag.model.ParkingSession;
import com.example.fastag.repository.ParkingLotRepository;
import com.example.fastag.repository.ParkingSessionRepository;
import com.example.fastag.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/parking-sessions")
public class ParkingSessionController {

    @Autowired
    private ParkingSessionRepository parkingSessionRepo;

    @Autowired
    private ParkingLotRepository parkingLotRepo;

    @Autowired
    private VehicleRepository vehicleRepo;

    @GetMapping
    public List<ParkingSession> getAll() {
        return parkingSessionRepo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ParkingSession> getById(@PathVariable Long id) {
        return parkingSessionRepo.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ParkingSession> create(@RequestBody ParkingSession ps) {
        // check references
        if(ps.getParkingLot() != null && ps.getParkingLot().getParkingLotId() != null) {
            parkingLotRepo.findById(ps.getParkingLot().getParkingLotId())
                          .ifPresent(ps::setParkingLot);
        }
        if(ps.getVehicle() != null && ps.getVehicle().getVehicleId() != null) {
            vehicleRepo.findById(ps.getVehicle().getVehicleId())
                       .ifPresent(ps::setVehicle);
        }
        ParkingSession saved = parkingSessionRepo.save(ps);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ParkingSession> update(@PathVariable Long id, @RequestBody ParkingSession req) {
        return parkingSessionRepo.findById(id).map(existing -> {
            existing.setEntryTime(req.getEntryTime());
            existing.setExitTime(req.getExitTime());
            existing.setStatus(req.getStatus());
            existing.setTotalFee(req.getTotalFee());
            existing.setPaidViaTag(req.isPaidViaTag());
            // optionally handle references
            return ResponseEntity.ok(parkingSessionRepo.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable Long id) {
        return parkingSessionRepo.findById(id).map(e -> {
            parkingSessionRepo.delete(e);
            return ResponseEntity.noContent().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
