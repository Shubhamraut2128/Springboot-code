package com.example.fastag.controller;

import com.example.fastag.model.PassIssued;
import com.example.fastag.repository.PassIssuedRepository;
import com.example.fastag.repository.PassSchemeRepository;
import com.example.fastag.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pass-issued")
public class PassIssuedController {

    @Autowired
    private PassIssuedRepository passIssuedRepo;

    @Autowired
    private PassSchemeRepository passSchemeRepo;

    @Autowired
    private VehicleRepository vehicleRepo;

    @GetMapping
    public List<PassIssued> getAll() {
        return passIssuedRepo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PassIssued> getById(@PathVariable Long id) {
        return passIssuedRepo.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<PassIssued> create(@RequestBody PassIssued passIssued) {
        // Resolve passScheme and vehicle if IDs exist
        if(passIssued.getPassScheme() != null && passIssued.getPassScheme().getPassSchemeId() != null) {
            passSchemeRepo.findById(passIssued.getPassScheme().getPassSchemeId())
                          .ifPresent(passIssued::setPassScheme);
        }
        if(passIssued.getVehicle() != null && passIssued.getVehicle().getVehicleId() != null) {
            vehicleRepo.findById(passIssued.getVehicle().getVehicleId())
                       .ifPresent(passIssued::setVehicle);
        }
        PassIssued saved = passIssuedRepo.save(passIssued);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PassIssued> update(@PathVariable Long id, @RequestBody PassIssued req) {
        return passIssuedRepo.findById(id).map(existing -> {
            existing.setIssueDate(req.getIssueDate());
            existing.setExpiryDate(req.getExpiryDate());
            existing.setUsedTrips(req.getUsedTrips());
            // If passScheme or vehicle changed, fetch them similarly
            return ResponseEntity.ok(passIssuedRepo.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable Long id) {
        return passIssuedRepo.findById(id).map(e -> {
            passIssuedRepo.delete(e);
            return ResponseEntity.noContent().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
