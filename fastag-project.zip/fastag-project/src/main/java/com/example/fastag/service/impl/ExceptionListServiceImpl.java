package com.example.fastag.service.impl;

import com.example.fastag.model.ExceptionList;
import com.example.fastag.repository.ExceptionListRepository;
import com.example.fastag.service.ExceptionListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ExceptionListServiceImpl implements ExceptionListService {

    @Autowired
    private ExceptionListRepository exceptionListRepository;

    @Override
    public List<ExceptionList> getAllExceptions() {
        return exceptionListRepository.findAll();
    }

    @Override
    public Optional<ExceptionList> getExceptionById(Long id) {
        return exceptionListRepository.findById(id);
    }

    @Override
    public ExceptionList createException(ExceptionList exceptionList) {
        return exceptionListRepository.save(exceptionList);
    }

    @Override
    public Optional<ExceptionList> updateException(Long id, ExceptionList request) {
        return exceptionListRepository.findById(id).map(existing -> {
            existing.setExcCode(request.getExcCode());
            existing.setExcDescription(request.getExcDescription());
            existing.setTagId(request.getTagId());
            existing.setPriority(request.getPriority());
            return exceptionListRepository.save(existing);
        });
    }

    @Override
    public boolean deleteException(Long id) {
        return exceptionListRepository.findById(id).map(e -> {
            exceptionListRepository.delete(e);
            return true;
        }).orElse(false);
    }
}
