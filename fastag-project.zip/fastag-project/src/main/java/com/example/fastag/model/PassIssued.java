package com.example.fastag.model;


import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "pass_issued", schema = "fastag")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PassIssued {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long passIssuedId;

    @ManyToOne
    @JoinColumn(name = "pass_scheme_id", nullable = false)
    private PassScheme passScheme;

    @ManyToOne
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle vehicle;

    private LocalDateTime issueDate;
    private LocalDateTime expiryDate;
    private Integer usedTrips;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    public void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (issueDate == null) {
            issueDate = LocalDateTime.now();
        }
        if (updatedAt == null) {
            updatedAt = LocalDateTime.now();
        }
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

	public Long getPassIssuedId() {
		return passIssuedId;
	}

	public void setPassIssuedId(Long passIssuedId) {
		this.passIssuedId = passIssuedId;
	}

	public PassScheme getPassScheme() {
		return passScheme;
	}

	public void setPassScheme(PassScheme passScheme) {
		this.passScheme = passScheme;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public LocalDateTime getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDateTime issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDateTime getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDateTime expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Integer getUsedTrips() {
		return usedTrips;
	}

	public void setUsedTrips(Integer usedTrips) {
		this.usedTrips = usedTrips;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
    
}
