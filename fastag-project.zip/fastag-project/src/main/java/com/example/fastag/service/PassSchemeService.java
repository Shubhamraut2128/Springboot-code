package com.example.fastag.service;

import com.example.fastag.model.PassScheme;

import java.util.List;
import java.util.Optional;

public interface PassSchemeService {
	
    List<PassScheme> getAllSchemes();
    
    Optional<PassScheme> getSchemeById(Long id);
    
    PassScheme createScheme(PassScheme scheme);
    
    Optional<PassScheme> updateScheme(Long id, PassScheme scheme);
    
    boolean deleteScheme(Long id);
}
