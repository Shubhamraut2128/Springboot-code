package com.example.fastag.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "parking_lot", schema = "fastag")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ParkingLot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long parkingLotId;

    @ManyToOne
    @JoinColumn(name = "plaza_id", nullable = false)
    private Plaza plaza;

    @Column(nullable = false, length = 100)
    private String lotName;

    private Integer floorNumber;
    private Integer capacity;
    private boolean isActive;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // ParkingLot can have multiple sessions
    @OneToMany(mappedBy = "parkingLot", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ParkingSession> parkingSessions = new ArrayList<>();

    @PrePersist
    public void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

	public Long getParkingLotId() {
		return parkingLotId;
	}

	public void setParkingLotId(Long parkingLotId) {
		this.parkingLotId = parkingLotId;
	}

	public Plaza getPlaza() {
		return plaza;
	}

	public void setPlaza(Plaza plaza) {
		this.plaza = plaza;
	}

	public String getLotName() {
		return lotName;
	}

	public void setLotName(String lotName) {
		this.lotName = lotName;
	}

	public Integer getFloorNumber() {
		return floorNumber;
	}

	public void setFloorNumber(Integer floorNumber) {
		this.floorNumber = floorNumber;
	}

	public Integer getCapacity() {
		return capacity;
	}

	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<ParkingSession> getParkingSessions() {
		return parkingSessions;
	}

	public void setParkingSessions(List<ParkingSession> parkingSessions) {
		this.parkingSessions = parkingSessions;
	}
    
	
	public ParkingLot(Long parkingLotId, Plaza plaza, String lotName, Integer floorNumber, Integer capacity,
			boolean isActive, LocalDateTime createdAt, LocalDateTime updatedAt, List<ParkingSession> parkingSessions) {
		super();
		this.parkingLotId = parkingLotId;
		this.plaza = plaza;
		this.lotName = lotName;
		this.floorNumber = floorNumber;
		this.capacity = capacity;
		this.isActive = isActive;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.parkingSessions = parkingSessions;
	}

	public ParkingLot() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	@Override
	public String toString() {
		return "ParkingLot [parkingLotId=" + parkingLotId + ", plaza=" + plaza + ", lotName=" + lotName
				+ ", floorNumber=" + floorNumber + ", capacity=" + capacity + ", isActive=" + isActive + ", createdAt="
				+ createdAt + ", updatedAt=" + updatedAt + ", parkingSessions=" + parkingSessions + "]";
	}
	
    
	
}
