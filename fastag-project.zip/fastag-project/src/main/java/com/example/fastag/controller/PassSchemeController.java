package com.example.fastag.controller;

import com.example.fastag.model.PassScheme;
import com.example.fastag.repository.PassSchemeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pass-schemes")
public class PassSchemeController {

    @Autowired
    private PassSchemeRepository passSchemeRepo;

    @GetMapping
    public List<PassScheme> getAll() {
        return passSchemeRepo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PassScheme> getById(@PathVariable Long id) {
        return passSchemeRepo.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public PassScheme create(@RequestBody PassScheme ps) {
        return passSchemeRepo.save(ps);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PassScheme> update(@PathVariable Long id, @RequestBody PassScheme req) {
        return passSchemeRepo.findById(id).map(existing -> {
            existing.setSchemeName(req.getSchemeName());
            existing.setVehicleClassId(req.getVehicleClassId());
            existing.setPassType(req.getPassType());
            existing.setAllowedTrips(req.getAllowedTrips());
            existing.setAmount(req.getAmount());
            existing.setCurrency(req.getCurrency());
            existing.setDescription(req.getDescription());
            return ResponseEntity.ok(passSchemeRepo.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable Long id) {
        return passSchemeRepo.findById(id).map(p -> {
            passSchemeRepo.delete(p);
            return ResponseEntity.noContent().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}

