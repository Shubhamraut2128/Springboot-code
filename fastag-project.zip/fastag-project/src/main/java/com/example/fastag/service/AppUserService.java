package com.example.fastag.service;

import com.example.fastag.model.AppUser;

import java.util.List;
import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface AppUserService extends UserDetailsService {
	
    AppUser saveUser(AppUser user);
    
    Optional<AppUser> getUserById(Long id);
    
    Optional<AppUser> getUserByUsername(String username);
    
    List<AppUser> getAllUsers();
    
    void deleteUser(Long id);
}
