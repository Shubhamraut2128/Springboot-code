package com.example.fastag.controller;

import com.example.fastag.model.ParkingLot;
import com.example.fastag.model.Plaza;
import com.example.fastag.repository.ParkingLotRepository;
import com.example.fastag.repository.PlazaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/parking-lots")
public class ParkingLotController {

    @Autowired
    private ParkingLotRepository parkingLotRepo;

    @Autowired
    private PlazaRepository plazaRepo;

    @GetMapping
    public List<ParkingLot> getAll() {
        return parkingLotRepo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ParkingLot> getById(@PathVariable Long id) {
        return parkingLotRepo.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ParkingLot> create(@RequestBody ParkingLot lot) {
        if (lot.getPlaza() == null || lot.getPlaza().getPlazaId() == null) {
            return ResponseEntity.badRequest().build();
        }
        return plazaRepo.findById(lot.getPlaza().getPlazaId()).map(plaza -> {
            lot.setPlaza(plaza);
            ParkingLot saved = parkingLotRepo.save(lot);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.badRequest().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<ParkingLot> update(@PathVariable Long id, @RequestBody ParkingLot req) {
        return parkingLotRepo.findById(id).map(existing -> {
            existing.setLotName(req.getLotName());
            existing.setFloorNumber(req.getFloorNumber());
            existing.setCapacity(req.getCapacity());
            existing.setActive(req.isActive());
            // optionally handle plaza changes
            return ResponseEntity.ok(parkingLotRepo.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable Long id) {
        return parkingLotRepo.findById(id).map(l -> {
            parkingLotRepo.delete(l);
            return ResponseEntity.noContent().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
