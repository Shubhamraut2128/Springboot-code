package com.example.fastag.service;

import com.example.fastag.model.Lane;

import java.util.List;
import java.util.Optional;

public interface LaneService {
	
	     List<Lane> getAllLanes();
	     
	    Optional<Lane> getLaneById(Long id);
	    
	    Optional<Lane> createLane(Lane lane);
	    
	    Optional<Lane> updateLane(Long id, Lane lane);
	    
	    boolean deleteLane(Long id);
}
