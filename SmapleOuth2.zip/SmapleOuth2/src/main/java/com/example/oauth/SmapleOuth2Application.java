package com.example.oauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmapleOuth2Application {

	public static void main(String[] args) {
		SpringApplication.run(SmapleOuth2Application.class, args);
	}

}